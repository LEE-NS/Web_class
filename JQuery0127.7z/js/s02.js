$('.box1 span').text('흐림으로 바뀜랄라라라라라');

let day = '가나다일'
$('.box2 span').text(day)

let p31 = $('.p31').text()
$('.box3 .p32').text(p31)

let userName = $('.box4 .p41').text() + '기'
$('.box4 .p42').html(`<strong>${userName}</strong>님 환영합니다!`)