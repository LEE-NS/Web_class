$('.box1 button').click(function() {
    $('.box1 p').animate({
        marginLeft: 200,
        marginTop: 200,
        width: 500
    }, 1500)
})